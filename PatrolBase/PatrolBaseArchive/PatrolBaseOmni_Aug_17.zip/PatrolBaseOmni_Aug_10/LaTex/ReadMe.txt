Notes from meeting on 22 June 2017 with
Professor Chin, Jesse, and me.
Format notes for structuring write-up.

Who is our target audience?
How to structure the report?

How will it operate?

*************************************************************
Outline idea:
--Title page.
--Abstract.
--Participants/acknowledgement.
--Executive summary.
--Goals, mission statement.
--
--Methodology
	subject matter expert, field manuals.
	translation into a state machine (diagram).
	Why do we trust the high-level state machine (motivation)
	    because Jesse (qualifications)...
--General structure of project.  Folder strucute.  Name conventions.
--Overall diagram.
--State machines
    ssmPB
      Planning
      MoveToORP
      etl.
--Results/Discussion.
--Future Research (if we had more time--reiterate).

***************************************************************
Jesse says:
Inputs--> patrol base in HOL --> HOL
Inputs are variables representing unit and soldier states.
Goes into HOL.
Output-->secure or insecure?

Professor Chin says:
Other stuff...I was distracted.

Look at master's thesis...

Yihong
